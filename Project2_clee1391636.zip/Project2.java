// Create and play a new game.

public class Project2 {
    public static void main(String[] args) {
        Game game = new Game();
        game.playGame();
    }
}